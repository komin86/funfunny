package com.example.funfunny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunfunnyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FunfunnyApplication.class, args);
	}

}
