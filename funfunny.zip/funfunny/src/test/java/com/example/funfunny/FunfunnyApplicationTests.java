package com.example.funfunny;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FunfunnyApplicationTests {

	@Test
	void contextLoads() {
	}

}
